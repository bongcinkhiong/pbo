<html>
    <head>
        <title>LOGIN SEDERHANA</title>
    </head>
    <body>
        <h1>Membuat Login Sederhana</h1>
        <form action="login.php" method="post">
            <div>
                <label>Username</label>
                <input type="text" name="username">
            </div>
            <div>
                <label>Password</label>
                <input type="password" name="password">
            </div>
            <div>
                <input type="submit" value="Log In" name="login">
            </div>
        </form>
    </body>
</html>