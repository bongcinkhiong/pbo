<?php
include 'connect.php';

$username = $_POST['username'];
$password = $_POST['password'];

$query = mysqli_query($host,"select * from user where username='$username' and password='$password' ");
$cek = mysqli_num_rows($query);
echo $cek;

?>