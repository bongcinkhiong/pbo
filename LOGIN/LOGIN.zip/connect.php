<?php

// sambung ke localhost
$host = mysqli_connect("localhost","root","");

//sambung ke database
$db = mysqli_select_db($host,"pbo");
